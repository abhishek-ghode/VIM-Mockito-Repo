﻿using System;
using TechTalk.SpecFlow;

namespace Foo.specs
{
    [Binding]
    public class DemoParamExampleSteps
    {
        [Given]
        public void Given_I_have_entered_SOMENUMBER_and_SOMESTRING(int someNumber, string someString)
        {
            ScenarioContext.Current.Pending();
        }
        
        [When]
        public void When_Y()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then]
        public void Then_Z()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
