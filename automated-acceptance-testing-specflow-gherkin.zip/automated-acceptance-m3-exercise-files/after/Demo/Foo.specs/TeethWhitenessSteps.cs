﻿using System;
using TechTalk.SpecFlow;

namespace Foo.specs
{
    [Binding]
    public class TeethWhitenessSteps
    {
        string _brand;

        [Given]
        public void Given_I_m_using_BRAND_brand_toothpaste(string brand)
        {
            _brand = brand;
        }
        
        [When]
        public void When_I_brush_for_P0_minutes(int p0)
        {
            var brandName = _brand;
        }
        
        [Then]
        public void Then_the_teeth_look_P0_white(int p0)
        {
            ScenarioContext.Current.Pending();
        }
    }
}
