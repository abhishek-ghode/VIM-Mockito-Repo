﻿using System;
using TechTalk.SpecFlow;

namespace Foo.specs
{
    [Binding]
    public class DemoDataTableExampleSteps
    {
        [Given]
        public void Given_I_have_entered(Table table)
        {
            var secondNumberEntered = table.Rows[1][0];
        }
    }
}
