﻿using System;
using TechTalk.SpecFlow;

namespace Foo.specs
{
    [Binding]
    public class DemoSharingStepDefinitionsExampleSteps
    {
        [Given]
        public void Given_Something()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given]
        public void Given_Something_different()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Given]
        public void Given_Something_different_again()
        {
            ScenarioContext.Current.Pending();
        }
        

        // This step definition is shared by 3 scenarios
        [When]
        public void When_The_step_definition_for_this_is_shared()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then]
        public void Then_Something_else()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then]
        public void Then_Something_different_else()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then]
        public void Then_Something_else_different_again()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
