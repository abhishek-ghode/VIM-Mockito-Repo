The NuGet package binaries are not included in the demos.zip solutions.

To auto restore these packages when building, follow the instructions below.


In the Visual Studio 2012 Quick Launch (Ctrl+Q) type: "package manager general" and hit enter.

In the Package Manager, General options:

- Enable Allow NuGet to download missing packages
- Enable Automatically check for missing packages during build in Visual Studio

After opening the "After" solution in Visual Studio:

- Expand the "DemoExampleSite" project
- Right-click on "Register.aspx" and choose "Set As Start Page"
- Run the solution (e.g. by pressing F5) - this will ensure the web server is running for subsequent WatiN test runs

Note: if you are running IE11 you may need to run Visual Studio as an Administrator. To do this hold CTRL while right-clicking the Visual Studio icon. From the popup menu choose "Run as administrator".
