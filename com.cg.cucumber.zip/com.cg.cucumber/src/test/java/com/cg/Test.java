package com.cg;

import org.junit.runner.RunWith;

import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

//@RunWith(Cucumber.class)
public class Test {
	


}
