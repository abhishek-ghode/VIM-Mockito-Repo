package comc.g;


import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.DataTable;


public class Sample {
	@Given("^a precondition is valid$")
	public void a_precondition_is_valid() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
//		System.out.println("Hello, world!");
	}

	
	@When("^an action is performed$")
	public void an_action_is_performed(DataTable table) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	    throw new PendingException();
//	    System.out.println("Action performed...");
	}
	
	@Then("^something should be asserted$")
	public void something_should_be_asserted() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
//		throw new PendingException();
		System.out.println("Hello, world!");
//		Assert.fail("Not implemented");
	}
	
	public void sample_test(){
		
		System.out.println("Hello, world! CUCUMBER");
	}
}
